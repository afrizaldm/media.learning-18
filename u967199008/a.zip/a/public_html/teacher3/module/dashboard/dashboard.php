<section>
    <!-- Content -->
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>
        </div>
    </div><!-- /Row -->

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"></div>
                <div class="panel-body">
                    <center>
                        <img src="../file/images/tudet1.jpeg"/>
                        <h1>Welcome to Hybrid</h1>
                        <h1>Learning System</h1>
                    </center>
                </div>
            </div>
        </div>
    </div><!-- /Row -->
</section>