<?php
error_reporting(0);
session_start();
ob_start();

$con = mysqli_connect('localhost', 'root', '', 'medilearn');

//koneksi mysql biasa
mysql_connect("localhost", "root", "");
mysql_select_db("medilearn");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

?>
